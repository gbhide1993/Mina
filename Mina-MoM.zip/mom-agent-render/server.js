// server.js
/**
 * MoM Agent — WhatsApp → (Transcribe) → Summarize → Send back
 * Hosting: Render (free)
 * Integrations: Twilio WhatsApp, Hugging Face Whisper (free tier), optional OpenRouter (LLM)
 *
 * Endpoints:
 *  - POST /api/whatsapp/webhook   ← Twilio inbound webhook
 *  - GET  /api/health             ← health check
 */

require("dotenv").config();
const express = require("express");
const axios = require("axios");
const bodyParser = require("body-parser");
const Twilio = require("twilio");
const { HfInference } = require("@huggingface/inference");

const app = express();

// Twilio sends application/x-www-form-urlencoded by default
app.use(bodyParser.urlencoded({ extended: false }));

// ----- Environment & Clients -----
const {
  PORT = 3000,
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  TWILIO_WHATSAPP_NUMBER = "+14155238886",
  HF_API_TOKEN,                 // required for Whisper inference
  OPENROUTER_API_KEY,           // optional (for LLM summarization)
  OPENROUTER_MODEL = "meta-llama/llama-3.1-8b-instruct:free"
} = process.env;

const twilioClient = (TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN)
  ? Twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
  : null;

const hf = HF_API_TOKEN ? new HfInference(HF_API_TOKEN) : null;

function assertEnv() {
  const missing = [];
  if (!TWILIO_ACCOUNT_SID) missing.push("TWILIO_ACCOUNT_SID");
  if (!TWILIO_AUTH_TOKEN) missing.push("TWILIO_AUTH_TOKEN");
  if (!HF_API_TOKEN) missing.push("HF_API_TOKEN");
  if (missing.length) {
    console.warn("⚠️ Missing env:", missing.join(", "));
  } else {
    console.log("✅ Environment looks good");
  }
}
assertEnv();

// ----- Helpers -----

async function sendWhatsAppMessage(toPhone, body) {
  if (!twilioClient) {
    console.warn("Twilio client not configured; cannot send message.");
    return null;
  }
  const to = toPhone.startsWith("whatsapp:") ? toPhone : `whatsapp:${toPhone}`;
  const from = TWILIO_WHATSAPP_NUMBER.startsWith("whatsapp:")
    ? TWILIO_WHATSAPP_NUMBER
    : `whatsapp:${TWILIO_WHATSAPP_NUMBER}`;

  if (to === from) {
    throw new Error("Channels message should not have same From and To number");
  }

  const msg = await twilioClient.messages.create({ from, to, body });
  return msg.sid;
}

// Download Twilio Media (handles 302/307 + Basic Auth)
async function downloadAudio(mediaUrl) {
  const res = await axios.get(mediaUrl, {
    responseType: "arraybuffer",
    auth: {
      username: TWILIO_ACCOUNT_SID,
      password: TWILIO_AUTH_TOKEN
    },
    maxRedirects: 5
  });
  return Buffer.from(res.data);
}

// Whisper (Hugging Face) transcription
async function transcribeWithWhisper(audioBuffer) {
  if (!hf) throw new Error("HF_API_TOKEN not set");
  const result = await hf.automaticSpeechRecognition({
    model: "openai/whisper-base",
    data: audioBuffer
  });
  if (!result || !result.text) throw new Error("No transcription text returned");
  return result.text;
}

// Simple rule-based MoM (fallback if OPENROUTER_API_KEY not set)
function simpleMinutes(transcript) {
  const sentences = transcript.split(/[.!?]+/).map(s => s.trim()).filter(Boolean);
  const top = sentences.slice(0, 3).map(s => `• ${s[0].toUpperCase()}${s.slice(1)}`).join("\n");

  return `📝 *Meeting Minutes*\n\n*Summary:*\n${top || "• Discussion captured"}\n\n*Action Items:*\n• Follow up on key points\n• Assign responsibilities\n• Set deadlines\n\n*Transcript Snippet:*\n${transcript.slice(0, 280)}${transcript.length > 280 ? "…" : ""}`;
}

// LLM-powered MoM via OpenRouter (optional)
async function llmMinutes(transcript) {
  if (!OPENROUTER_API_KEY) return simpleMinutes(transcript);
  const prompt = "Create concise, structured Minutes of Meeting in WhatsApp-friendly markdown.\n" +
                 "Include:\n- Summary (3-5 bullets)\n- Decisions\n- Action Items (who/what/when)\n- Risks/Blockers\n- Next Steps\n" +
                 "Transcript:\n\n"""" + transcript + """"";

  const res = await axios.post(
    "https://openrouter.ai/api/v1/chat/completions",
    {
      model: OPENROUTER_MODEL,
      messages: [
        { role: "system", content: "You write crisp, structured Minutes of Meeting." },
        { role: "user", content: prompt }
      ]
    },
    {
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://render.com",
        "X-Title": "MoM Agent"
      },
      timeout: 60000
    }
  );
  const text = res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message && res.data.choices[0].message.content;
  return text || simpleMinutes(transcript);
}

// ----- Webhook -----
app.post("/api/whatsapp/webhook", async (req, res) => {
  const From = req.body.From || "";
  const Body = (req.body.Body || "").trim();
  const MediaUrl0 = req.body.MediaUrl0;
  const MediaContentType0 = req.body.MediaContentType0 || "";

  const senderPhone = From.replace("whatsapp:", "");

  try {
    // Activation hint
    if (Body && !MediaUrl0) {
      // Friendly guidance
      await sendWhatsAppMessage(senderPhone,
        "Hi 👋 Send me a *voice note or audio file* of your meeting. I’ll transcribe it and return crisp MoM."
      );
      // Return valid but empty TwiML to avoid 12200 warnings
      res.type("text/xml").send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
      return;
    }

    if (MediaUrl0 && MediaContentType0.startsWith("audio/")) {
      await sendWhatsAppMessage(senderPhone, "🎧 Got your audio. Processing… (usually under a minute)");

      // 1) Download audio from Twilio (fixes 307)
      const audio = await downloadAudio(MediaUrl0);

      // 2) Transcribe
      const transcript = await transcribeWithWhisper(audio);

      // 3) Summarize → MoM
      const minutes = await llmMinutes(transcript);

      // 4) Send back
      await sendWhatsAppMessage(senderPhone, minutes);

      res.type("text/xml").send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
      return;
    }

    // Non-audio media
    if (MediaUrl0) {
      await sendWhatsAppMessage(senderPhone, "I currently only process *audio* files 🎤. Please resend as a voice note or audio file.");
    }

    res.type("text/xml").send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
  } catch (err) {
    console.error("Webhook error:", err);
    try {
      await sendWhatsAppMessage(senderPhone, "❌ I hit an error processing your message. Please try again in a minute.");
    } catch {}
    res.type("text/xml").send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
  }
});

// Health
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    time: new Date().toISOString(),
    twilioConfigured: !!twilioClient,
    huggingfaceConfigured: !!hf
  });
});

// Boot
app.listen(PORT, () => {
  console.log(`🚀 MoM Agent running on port ${PORT}`);
  console.log(`Webhook: /api/whatsapp/webhook`);
});
