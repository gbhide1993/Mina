# MoM Agent (Render + Twilio + Hugging Face)

**WhatsApp → Audio → Whisper transcription → MoM summary → WhatsApp reply.**  
Free-friendly stack: Render free tier, Twilio Sandbox, Hugging Face free tier, optional OpenRouter for better summaries.

## Deploy on Render (free)
1. **Create repo** on GitHub with these files.
2. Go to **render.com → New → Web Service**, connect the repo.
3. Keep defaults; Render detects Node and runs `npm install` + `npm start`.
4. Set environment variables (use `.env.example` as guide).
5. After deploy, note your URL and set Twilio webhook to:
   ```
   https://YOUR-APP.onrender.com/api/whatsapp/webhook
   ```

## Twilio Sandbox
- Console → Messaging → Try it out → **WhatsApp Sandbox**.
- Set *When a message comes in* to your Render URL above.
- From: must be `whatsapp:+14155238886` (sandbox) when sending outbound.
- To: the user's WhatsApp number (cannot equal From).

## Why this fixes your earlier errors
- **307 during media download** → Axios with Basic Auth + `maxRedirects: 5` follows Twilio's signed URL redirects.
- **12200 schema warning** → We reply with valid (empty) TwiML: `<Response></Response>` and also send user-facing messages via API.

## Env Vars
See `.env.example`. You **must** set:
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_NUMBER`
- `HF_API_TOKEN` (free Hugging Face token)  
Optional:
- `OPENROUTER_API_KEY` (improves MoM quality)

## Test Flow
1. Send any text → bot replies with instructions.
2. Send a WhatsApp **voice note/audio** → bot says "Processing…".
3. Bot returns MoM in 1–2 messages.

## Notes
- Hugging Face model: `openai/whisper-base` via Inference API.
- For heavier usage, consider caching/transcript length limits and chunking.
